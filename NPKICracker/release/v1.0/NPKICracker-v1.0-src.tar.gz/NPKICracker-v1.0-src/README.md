# NPKICracker
NPKI Bruteforcing Tool made for Inc0gnito 2015

This is initial Release. Please wait for further instructions.

For now, this project is built under CodeBlocks 13.12.

Makefile will be added.


# Credits
Made by Hajin Jang (ied206, aka joveler), Junhyuk Lee (joonji)

NPKICracker is licensed under MIT License.

SEED Code from [KISA](https://seed.kisa.or.kr/iwt/ko/sup/EgovSeedInfo.do)