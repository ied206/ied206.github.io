#define MANIFEST                        1
#define IDI_MAINICON                    101
#define IDC_STATIC                      -1
